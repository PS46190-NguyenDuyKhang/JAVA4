package com.example.lab7.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @Column(length = 10)
    private String id;

    @Column(nullable = false, length = 100)
    private String name;

    // true = male, false = female
    @Column(nullable = false)
    private boolean gender;

    @Column(nullable = false)
    private double salary;

    public Employee() {
    }

    public Employee(String id, String name, boolean gender, double salary) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.salary = salary;
    }

    // getters & setters
    public String getId() {
        return id;
    }

    public void setId(String id) { this.id = id; }

    public String getName() {
        return name;
    }

    public void setName(String name) { this.name = name; }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) { this.gender = gender; }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) { this.salary = salary; }
}
