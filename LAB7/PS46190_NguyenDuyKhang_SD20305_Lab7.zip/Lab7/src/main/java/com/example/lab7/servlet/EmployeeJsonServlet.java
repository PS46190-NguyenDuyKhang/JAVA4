package com.example.lab7.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Bài 1: trả về JSON cố định.
 */
@WebServlet("/lab7/employee-json")
public class EmployeeJsonServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String json = """
                {
                  "manv": "TeoNV",
                  "hoTen": "Nguyễn Văn Tèo",
                  "gioiTinh": true,
                  "luong": 950.5
                }
                """;

        resp.getWriter().print(json);
        resp.flushBuffer();
    }
}
