package com.example.lab7.servlet;

import com.example.lab7.dao.EmployeeDAO;
import com.example.lab7.entity.Employee;
import com.example.lab7.util.RestIO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * RESTful API cho Employee:
 * GET    /employees          -> danh sách
 * GET    /employees/{id}     -> 1 nhân viên
 * POST   /employees          -> thêm mới
 * PUT    /employees/{id}     -> cập nhật
 * DELETE /employees/{id}     -> xóa
 *
 * Bài 3: GET /employees/search?name=keyword -> danh sách theo tên
 */
@WebServlet("/employees/*")
public class EmployeeRestServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final EmployeeDAO dao = new EmployeeDAO();

    // GET:/employees
    // GET:/employees/{id}
    // GET:/employees/search?name=...
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo(); // null, "/", "/NV01", "/search"

        // Bài 5: /employees/search?name=...
        if (pathInfo != null && pathInfo.equals("/search")) {
            String name = req.getParameter("name");
            if (name == null) name = "";
            List<Employee> list = dao.findByName(name);
            RestIO.writeObject(resp, list);
            return;
        }

        if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty()) {
            // trả về tất cả nhân viên
            List<Employee> list = dao.findAll();
            RestIO.writeObject(resp, list);
        } else {
            // /NV01 -> "NV01"
            String id = pathInfo.substring(1).trim();
            Employee e = dao.findById(id);
            RestIO.writeObject(resp, e);
        }
    }

    // POST:/employees
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Employee employee = RestIO.readObject(req, Employee.class);
        dao.create(employee);
        RestIO.writeObject(resp, employee);
    }

    // PUT:/employees/{id}
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getPathInfo().substring(1).trim();
        Employee employee = RestIO.readObject(req, Employee.class);
        // Đảm bảo id trong URL là id được lưu
        employee.setId(id);
        dao.update(employee);
        RestIO.writeEmptyObject(resp);
    }

    // DELETE:/employees/{id}
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getPathInfo().substring(1).trim();
        dao.delete(id);
        RestIO.writeEmptyObject(resp);
    }
}
