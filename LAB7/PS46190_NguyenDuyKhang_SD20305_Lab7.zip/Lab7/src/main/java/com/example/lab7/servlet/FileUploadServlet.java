package com.example.lab7.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Bài 2: Servlet nhận file upload bằng Fetch API,
 * lưu vào thư mục trên server, trả về JSON: name, type, size.
 */
@WebServlet("/lab7/upload")
@MultipartConfig
public class FileUploadServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIR = "uploads";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // lấy part theo tên 'file' từ form-data
        Part filePart = req.getPart("file");
        String fileName = filePart.getSubmittedFileName();
        String contentType = filePart.getContentType();
        long size = filePart.getSize();

        // Thư mục upload trong thư mục webapp (hoặc ngoài tùy bạn)
        String appPath = req.getServletContext().getRealPath("");
        File uploadDir = new File(appPath, UPLOAD_DIR);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        File savedFile = new File(uploadDir, fileName);
        try (InputStream is = filePart.getInputStream();
             FileOutputStream fos = new FileOutputStream(savedFile)) {

            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
        }

        // trả JSON về client
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");

        String json = String.format("""
                {
                  "name": "%s",
                  "type": "%s",
                  "size": %d
                }
                """, fileName, contentType, size);

        resp.getWriter().print(json);
        resp.flushBuffer();
    }
}
