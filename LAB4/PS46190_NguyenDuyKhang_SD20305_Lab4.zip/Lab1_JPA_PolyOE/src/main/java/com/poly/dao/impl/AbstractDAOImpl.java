package com.poly.dao.impl;

import com.poly.dao.AbstractDAO;
import com.poly.util.XJPA;
// FIX: Dùng jakarta.persistence
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.PersistenceException;
import java.util.List;
import java.lang.reflect.ParameterizedType; 

public abstract class AbstractDAOImpl<T, ID> implements AbstractDAO<T, ID> {
    
    private Class<T> entityClass;

    @SuppressWarnings("unchecked")
    public AbstractDAOImpl() {
        ParameterizedType genericSuperclass = (ParameterizedType) getClass().getGenericSuperclass();
        this.entityClass = (Class<T>) genericSuperclass.getActualTypeArguments()[0];
    }
    
    // Phương thức thực thi giao dịch CRUD (Trả về void để khớp Interface)
    private void executeTransaction(T entity, Action action) {
        EntityManager em = XJPA.getEntityManager();
        try {
            em.getTransaction().begin();
            switch (action) {
                case PERSIST: em.persist(entity); break; 
                case MERGE: em.merge(entity); break; 
                case REMOVE: em.remove(em.contains(entity) ? entity : em.merge(entity)); break; 
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Transaction error: " + action + " failed for " + entityClass.getSimpleName(), e);
        } finally {
            em.close();
        }
    }
    
    private enum Action { PERSIST, MERGE, REMOVE }

    // --- TRIỂN KHAI CÁC PHƯƠNG THỨC CỦA AbstractDAO (Đã khớp kiểu trả về: void) ---

    @Override
    public List<T> findAll() {
        EntityManager em = XJPA.getEntityManager();
        String jpql = "SELECT o FROM " + entityClass.getSimpleName() + " o";
        TypedQuery<T> query = em.createQuery(jpql, entityClass);
        List<T> result = query.getResultList();
        em.close();
        return result;
    }

    @Override
    public T findById(ID id) {
        EntityManager em = XJPA.getEntityManager();
        T entity = em.find(entityClass, id);
        em.close();
        return entity;
    }

    @Override
    public void create(T entity) {
        executeTransaction(entity, Action.PERSIST);
    }

    @Override
    public void update(T entity) {
        executeTransaction(entity, Action.MERGE);
    }

    @Override
    public void deleteById(ID id) {
        T entity = findById(id);
        if (entity != null) {
            executeTransaction(entity, Action.REMOVE);
        } else {
             System.err.println("Entity " + entityClass.getSimpleName() + " with ID " + id + " not found for deletion.");
        }
    }
}