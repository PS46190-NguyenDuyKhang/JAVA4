package com.poly.test;

import com.poly.manager.UserManager;

public class UserTest {
    public static void main(String[] args) {
        UserManager manager = new UserManager();
        int pageNumber = 2; 
        int pageSize = 5; 
        
        System.out.println("====== BẮT ĐẦU KIỂM THỬ LAB 1 JPA ======");
        
        
        manager.create(); 
        
       
        manager.findById();
        
        
        manager.update();
        
       
        manager.findAll();
        
       
        manager.deleteById();
        
        manager.findUserEmails();
        
        manager.paginateUsers(pageNumber, pageSize);
        
        System.out.println("====== KẾT THÚC KIỂM THỬ ======");
        
        manager.close();
    }
}