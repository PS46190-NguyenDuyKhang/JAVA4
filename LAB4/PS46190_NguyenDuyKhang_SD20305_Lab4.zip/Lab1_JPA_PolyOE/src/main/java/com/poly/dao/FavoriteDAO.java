package com.poly.dao;

import com.poly.entity.Favorite;

// Kế thừa AbstractDAO cho Entity Favorite (Khóa chính là Long)
public interface FavoriteDAO extends AbstractDAO<Favorite, Long> {
    // Có thể bổ sung các phương thức tùy chỉnh cho Favorite
}