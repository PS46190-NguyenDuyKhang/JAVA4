package com.poly.servlet;

import com.poly.dao.impl.ShareDAOImpl;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/report/share")
public class ShareReportServlet extends HttpServlet {
    
    private ShareDAOImpl dao = new ShareDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            // Gọi phương thức thống kê từ DAO
            List<Object[]> report = dao.findShareReport(); 
            
            // Đặt kết quả vào request để JSP hiển thị
            req.setAttribute("report", report);
            req.setAttribute("message", "Báo cáo chia sẻ tổng hợp.");
            
        } catch (Exception e) {
            req.setAttribute("message", "Lỗi truy vấn báo cáo: " + e.getMessage());
            e.printStackTrace();
        }
        
        req.getRequestDispatcher("/pages/share-report.jsp").forward(req, resp);
    }
}