package com.poly.servlet;

import com.poly.dao.UserDAO;

import com.poly.dao.impl.UserDAOImpl;
import com.poly.entity.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/favorite/list")
public class FavoriteServlet extends HttpServlet {
    
    private static final String DEFAULT_USER_ID = "user01"; 
  
    private UserDAOImpl userDAO = new UserDAOImpl(); 

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        String userId = DEFAULT_USER_ID; 
        User user = userDAO.findByIdWithFavorites(userId); 

        if (user != null) {
            req.setAttribute("user", user);
            req.setAttribute("message", "Các video yêu thích của " + user.getFullname());
        } else {
            req.setAttribute("message", "Lỗi: Không tìm thấy người dùng với ID: " + userId);
        }
        
        req.getRequestDispatcher("/pages/favorite.jsp").forward(req, resp);
    }
}