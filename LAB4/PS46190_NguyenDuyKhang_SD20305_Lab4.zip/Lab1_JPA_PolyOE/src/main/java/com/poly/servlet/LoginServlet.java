package com.poly.servlet;

import com.poly.dao.UserDAO;
import com.poly.dao.impl.UserDAOImpl;
import com.poly.entity.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; // Sử dụng HttpSession để duy trì trạng thái đăng nhập
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    
    private UserDAO dao = new UserDAOImpl();

    // GET: Hiển thị form đăng nhập
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
    }

    // POST: Xử lý đăng nhập
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        String usernameOrEmail = req.getParameter("username"); // Dùng chung trường username cho ID hoặc Email
        String password = req.getParameter("password");
        
        // 1. Kiểm tra sự tồn tại của User (Bằng ID hoặc Email)
        // Gọi findByIdOrEmail() thay vì findById()
        User user = dao.findByIdOrEmail(usernameOrEmail, usernameOrEmail); 
        
        if (user == null) {
            // Lỗi: User không tồn tại
            req.setAttribute("error", "Tên đăng nhập hoặc Email không tồn tại.");
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
            return;
        }

        // 2. Kiểm tra mật khẩu
        if (!user.getPassword().equals(password)) {
            // Lỗi: Sai mật khẩu
            req.setAttribute("error", "Mật khẩu không chính xác.");
            req.setAttribute("username", usernameOrEmail); // Giữ lại username đã nhập
            req.getRequestDispatcher("/pages/login.jsp").forward(req, resp);
            return;
        }
        
        // 3. Đăng nhập thành công: Duy trì thông tin User vào Session
        HttpSession session = req.getSession();
        session.setAttribute("user", user);
        session.setAttribute("isLogin", true);
        
        // 4. Chuyển hướng về Trang Chủ
        resp.sendRedirect(req.getContextPath() + "/home");
    }
}