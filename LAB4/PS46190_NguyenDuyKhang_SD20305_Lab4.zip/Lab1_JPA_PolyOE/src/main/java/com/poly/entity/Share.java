package com.poly.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Share")
public class Share {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Khóa chính tự tăng
    @Column(name = "Id")
    private Long id;

    // Quan hệ N-1 với User
    @ManyToOne
    @JoinColumn(name = "UserId") // Khóa ngoại
    private User user;

    // Quan hệ N-1 với Video
    @ManyToOne
    @JoinColumn(name = "VideoId") // Khóa ngoại
    private Video video;

    @Column(name = "Emails")
    private String emails; // Danh sách emails đã chia sẻ

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ShareDate")
    private Date shareDate = new Date();

    // --- Constructors, Getters/Setters ---
    public Share() {}
    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}
    public User getUser() {return user;}
    public void setUser(User user) {this.user = user;}
    public Video getVideo() {return video;}
    public void setVideo(Video video) {this.video = video;}
    public String getEmails() {return emails;}
    public void setEmails(String emails) {this.emails = emails;}
    public Date getShareDate() {return shareDate;}
    public void setShareDate(Date shareDate) {this.shareDate = shareDate;}
}