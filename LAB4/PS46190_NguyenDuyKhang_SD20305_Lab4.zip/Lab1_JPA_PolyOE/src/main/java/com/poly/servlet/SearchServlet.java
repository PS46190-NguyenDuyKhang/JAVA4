package com.poly.servlet;

import com.poly.dao.VideoDAO;
import com.poly.dao.impl.VideoDAOImpl;
import com.poly.entity.Video;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/search")
public class SearchServlet extends HttpServlet {
    
    private VideoDAO videoDAO = new VideoDAOImpl();
    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        String keyword = req.getParameter("keyword");
        List<Video> results = null;
        String message = "Nhập từ khóa để tìm kiếm video.";
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            try {
                // 1. Gọi DAO để tìm kiếm theo từ khóa (JPQL LIKE)
                results = videoDAO.findByTitleKeyword(keyword); 
                
                if (results.isEmpty()) {
                    message = "Không tìm thấy video nào chứa từ khóa '" + keyword + "'.";
                } else {
                    message = "Tìm thấy " + results.size() + " kết quả cho từ khóa '" + keyword + "'.";
                }
                
            } catch (Exception e) {
                message = "Lỗi truy vấn: " + e.getMessage();
                e.printStackTrace();
            }
        }
        
        // 2. Set attributes để JSP hiển thị
        req.setAttribute("videos", results);
        req.setAttribute("message", message);
        req.setAttribute("currentKeyword", keyword); // Giữ lại từ khóa đã nhập
        
        // 3. Chuyển tiếp đến trang JSP
        req.getRequestDispatcher("/pages/search.jsp").forward(req, resp);
    }
}