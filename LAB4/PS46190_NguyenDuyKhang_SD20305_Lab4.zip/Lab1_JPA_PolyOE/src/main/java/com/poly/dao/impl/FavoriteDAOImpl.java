package com.poly.dao.impl;

import com.poly.dao.FavoriteDAO;
import com.poly.entity.Favorite;

public class FavoriteDAOImpl extends AbstractDAOImpl<Favorite, Long> implements FavoriteDAO {
    // Không cần viết lại code CRUD
}