package com.poly.servlet;

import com.poly.dao.FavoriteDAO;
import com.poly.dao.impl.FavoriteDAOImpl;
import com.poly.entity.Favorite;
// Sử dụng javax.servlet.* cho Tomcat 9.0
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/favorite/all")
public class FavoriteListServlet extends HttpServlet {
    
    // Khai báo DAO
    private FavoriteDAO dao = new FavoriteDAOImpl(); 

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        // 1. Truy vấn tất cả Favorite (DAO đã xử lý việc lấy dữ liệu)
        List<Favorite> favorites;
        String message = "Danh sách tất cả video yêu thích.";
        
        try {
            favorites = dao.findAll(); 
        } catch (Exception e) {
            favorites = null;
            message = "Lỗi khi truy vấn dữ liệu Favorites: " + e.getMessage();
            e.printStackTrace();
        }
        
        // 2. Chuyển tiếp danh sách Favorite và thông báo đến JSP
        req.setAttribute("message", message);
        req.setAttribute("favorites", favorites); 
        
        // Chuyển tiếp đến trang JSP hiển thị bảng
        req.getRequestDispatcher("/pages/all-favorites.jsp").forward(req, resp);
    }
}