package com.poly.dao;

import java.util.List;

/**
 * Giao diện DAO chung (Generic DAO) định nghĩa các thao tác CRUD cơ bản.
 * @param <T> Loại Entity (User, Video, Favorite...)
 * @param <ID> Loại khóa chính (String, Long...)
 */
public interface AbstractDAO<T, ID> {

    /**Truy vấn tất cả các thực thể*/
    List<T> findAll();

    /**Truy vấn thực thể theo ID*/
    T findById(ID id);

    /**Thêm mới thực thể*/
    void create(T entity); // FIX: Đã đổi return type sang void

    /**Cập nhật thực thể*/
    void update(T entity); // FIX: Đã đổi return type sang void

    /**Xóa thực thể theo ID*/
    void deleteById(ID id);
}