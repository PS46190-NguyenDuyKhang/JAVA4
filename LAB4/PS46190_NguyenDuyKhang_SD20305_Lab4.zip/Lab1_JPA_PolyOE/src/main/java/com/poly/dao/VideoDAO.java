package com.poly.dao;

import java.util.List;

import com.poly.entity.Video;

// Kế thừa AbstractDAO cho Entity Video (Khóa chính là String)
public interface VideoDAO extends AbstractDAO<Video, String> {

	List<Video> findByTitleKeyword(String keyword);
    // Có thể bổ sung các phương thức tùy chỉnh cho Video ở đây
}