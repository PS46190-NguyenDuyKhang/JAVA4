package com.poly.test;

import com.poly.dao.impl.UserDAOImpl;
import com.poly.dao.impl.VideoDAOImpl;
import com.poly.dao.impl.ShareDAOImpl;
import com.poly.entity.User;
import com.poly.entity.Video;
import com.poly.entity.Share;
import java.util.List;
import java.util.Date; // Cần cho các báo cáo thời gian

public class Lab4Test {
    
    public static void main(String[] args) {
        UserDAOImpl userDAO = new UserDAOImpl();
        VideoDAOImpl videoDAO = new VideoDAOImpl();
        ShareDAOImpl shareDAO = new ShareDAOImpl();

        System.out.println("====== LAB 4: BÀI 1 - TRUY VẤN JPQL NÂNG CAO ======");
        
        // --- Yêu cầu 1: Tìm User theo ID hoặc Email ---
        // (Sử dụng user01 và email teo@poly.vn đã tạo trong data_lab3.sql)
        System.out.println("\n--- 1. Tìm User theo ID/Email ('user01') ---");
        User user = userDAO.findByIdOrEmail("user01", "some_non_existent_email@x.com");
        if (user != null) {
            System.out.println("  User tìm thấy: " + user.getFullname() + " (" + user.getEmail() + ")");
        } else {
            System.out.println("  Không tìm thấy user.");
        }
        
        // --- Yêu cầu 2: Tìm Video có title chứa từ khóa ---
        System.out.println("\n--- 2. Tìm Video chứa từ khóa ('JPA') ---");
        List<Video> keywordVideos = videoDAO.findByTitleKeyword("JPA");
        keywordVideos.forEach(v -> System.out.println("  Video: " + v.getTitle()));

        // --- Yêu cầu 3: Truy vấn 10 video được yêu thích nhiều nhất ---
        System.out.println("\n--- 3. Top 10 Video được yêu thích nhất ---");
        List<Object[]> topLiked = videoDAO.findTop10MostLiked();
        topLiked.forEach(item -> {
            Video v = (Video) item[0];
            Long count = (Long) item[1];
            System.out.println("  " + v.getTitle() + " - Lượt thích: " + count);
        });

        // --- Yêu cầu 4: Tìm các video không được ai thích ---
        System.out.println("\n--- 4. Video không được ai thích ---");
        List<Video> unliked = videoDAO.findUnlikedVideos();
        if (unliked.isEmpty()) {
            System.out.println("  Tất cả video đều có lượt thích.");
        } else {
            unliked.forEach(v -> System.out.println("  Video chưa được thích: " + v.getTitle()));
        }
        
        // --- Yêu cầu 5: Tìm video được chia sẻ trong năm 2024 ---
        // (Dữ liệu mẫu đang là năm 2025, nên dùng năm hiện tại để kiểm tra)
        System.out.println("\n--- 5. Video được chia sẻ trong năm [Năm Hiện Tại] ---");
        // Giả định bạn đang kiểm tra năm 2025 theo timestamp hệ thống
        List<Share> sharedRecent = shareDAO.findSharedIn2024(); 
        if (sharedRecent.isEmpty()) {
            System.out.println("  Không tìm thấy video được chia sẻ trong năm 2024.");
        } else {
            sharedRecent.forEach(s -> System.out.println("  Video: " + s.getVideo().getTitle() + " - Ngày: " + s.getShareDate()));
        }

        // --- Yêu cầu 6: Báo cáo chia sẻ tổng hợp (Web) ---
        System.out.println("\n--- 6. Báo cáo Chia sẻ (Kiểm tra trên Web: /report/share) ---");
        List<Object[]> report = shareDAO.findShareReport();
        if (!report.isEmpty()) {
            System.out.println("  Báo cáo đã được truy vấn thành công.");
            System.out.printf("  %-30s | %-6s | %-15s\n", "VIDEO TITLE", "COUNT", "MIN DATE");
            System.out.printf("  %-30s | %-6d | %-15s\n", 
                                (String)report.get(0)[0], 
                                (Long)report.get(0)[1], 
                                (Date)report.get(0)[2]); // Chỉ in dòng đầu tiên
        } else {
             System.out.println("  Báo cáo trống (Chưa có dữ liệu chia sẻ).");
        }
        
        System.out.println("=========================================================");
    }
}