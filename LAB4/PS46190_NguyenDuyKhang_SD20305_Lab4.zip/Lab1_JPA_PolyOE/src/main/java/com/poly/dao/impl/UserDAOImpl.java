package com.poly.dao.impl;

import com.poly.dao.UserDAO;
import com.poly.entity.User;
import com.poly.util.XJPA;
// Bắt buộc dùng Jakarta Persistence cho Hibernate 6
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.NoResultException;
import java.util.List;

/**
 * Lớp triển khai các chức năng truy xuất dữ liệu (DAO) cho User.
 * Kế thừa AbstractDAOImpl để quản lý các thao tác CRUD cơ bản.
 * Đã sửa lỗi trùng lặp phương thức và lỗi biên dịch.
 */
public class UserDAOImpl extends AbstractDAOImpl<User, String> implements UserDAO {

    // LƯU Ý: Các phương thức CRUD cơ bản (findAll, create, update, deleteById)
    // ĐƯỢC KẾ THỪA TỪ AbstractDAOImpl, không cần viết lại.

    // ====================================================
    // BỔ SUNG: findByIdOrEmail (Yêu cầu Bài 2 Lab 4)
    // ====================================================

    /**
     * Tìm User theo ID hoặc Email.
     * @return User hoặc null nếu không tìm thấy.
     */
    @Override
    public User findByIdOrEmail(String id, String email) {
        // Mở EntityManager mới
        EntityManager em = XJPA.getEntityManager();
        User user = null;
        try {
            // JPQL: Sử dụng OR để tìm kiếm theo ID hoặc Email
            String jpql = "SELECT u FROM User u WHERE u.id = :id OR u.email = :email";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("id", id);
            query.setParameter("email", email);
            
            user = query.getSingleResult(); 
        } catch (NoResultException e) {
            user = null;
        } finally {
            em.close(); // Đóng EntityManager
        }
        return user;
    }
    
    // ====================================================
    // BỔ SUNG: findByIdWithFavorites (Giải quyết Lazy Loading - Lab 3)
    // ====================================================

    /**
     * Truy vấn User và tải danh sách Favorites cùng lúc (Fetch Join).
     */
    public User findByIdWithFavorites(String id) {
        EntityManager em = XJPA.getEntityManager();
        User user = null;
        try {
            // JPQL Fetch Join: Tải User và Favorites cùng lúc
            String jpql = "SELECT u FROM User u LEFT JOIN FETCH u.favorites WHERE u.id = :uid";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("uid", id);
            user = query.getSingleResult();
        } catch (NoResultException e) {
            // Bỏ qua nếu không tìm thấy
        } finally {
            em.close();
        }
        return user;
    }
    
    // ====================================================
    // Ghi đè các phương thức từ UserDAO (trỏ đến lớp cha)
    // ====================================================
    
    @Override public List<User> findAll() { return super.findAll(); }
    @Override public User findById(String id) { return super.findById(id); }
    @Override public void create(User item) { super.create(item); }
    @Override public void update(User item) { super.update(item); }
    @Override public void deleteById(String id) { super.deleteById(id); }
}