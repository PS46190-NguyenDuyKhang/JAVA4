package com.poly.dao;

import com.poly.entity.Share;

// Kế thừa AbstractDAO cho Entity Share (Khóa chính là Long)
public interface ShareDAO extends AbstractDAO<Share, Long> {
    // Có thể bổ sung các phương thức tùy chỉnh cho Share
}