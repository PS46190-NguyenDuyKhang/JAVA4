package com.poly.dao.impl;

import com.poly.dao.VideoDAO;
import com.poly.entity.Video;
import com.poly.util.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.Query;
import java.util.List;

public class VideoDAOImpl extends AbstractDAOImpl<Video, String> implements VideoDAO {

    // ... (Các phương thức findPage, count đã có) ...

    /**
     * Tìm các video có title chứa từ khóa (Yêu cầu 2).
     */
    public List<Video> findByTitleKeyword(String keyword) {
        EntityManager em = XJPA.getEntityManager();
        try {
            String jpql = "SELECT v FROM Video v WHERE v.title LIKE :keyword";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            query.setParameter("keyword", "%" + keyword + "%"); // Thêm % cho LIKE search
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Truy vấn 10 video được yêu thích nhiều nhất (Yêu cầu 3).
     * @return List<Object[]>: [Video, Số lượt thích]
     */
    public List<Object[]> findTop10MostLiked() {
        EntityManager em = XJPA.getEntityManager();
        try {
            String jpql = "SELECT v, COUNT(f) FROM Video v JOIN Favorite f ON v.id = f.video.id GROUP BY v ORDER BY COUNT(f) DESC";
            
            Query query = em.createQuery(jpql); // Dùng Query vì trả về Object[]
            query.setMaxResults(10); // Giới hạn 10 kết quả
            
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Tìm các video không được ai thích (Yêu cầu 4).
     */
    public List<Video> findUnlikedVideos() {
        EntityManager em = XJPA.getEntityManager();
        try {
            // Dùng LEFT JOIN và kiểm tra khóa ngoại (Favorite.id) có là NULL hay không
            String jpql = "SELECT v FROM Video v LEFT JOIN Favorite f ON v.id = f.video.id WHERE f.id IS NULL";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}