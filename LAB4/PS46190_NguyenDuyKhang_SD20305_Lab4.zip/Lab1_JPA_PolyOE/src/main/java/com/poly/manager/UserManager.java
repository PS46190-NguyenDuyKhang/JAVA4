package com.poly.manager;

import com.poly.entity.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class UserManager {

  
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
    EntityManager em = factory.createEntityManager();

    public void findAll() {
        String jpql = "SELECT o FROM User o";
        
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        List<User> list = query.getResultList();
        
        System.out.println("--- KẾT QUẢ TỪ findAll() ---");
        list.forEach(user -> {
            String fullname = user.getFullname();
            boolean admin = user.getAdmin();
            System.out.println(fullname + " : " + admin);
        });
    }


    public void findById() {
        
        User user = em.find(User.class, "U01"); 
        
        if (user != null) {
            String fullname = user.getFullname();
            boolean admin = user.getAdmin();
            System.out.println("--- KẾT QUẢ TỪ findById(U01) ---");
            System.out.println(fullname + " : " + admin);
        } else {
            System.out.println("--- KHÔNG TÌM THẤY USER VỚI ID: U01 ---");
        }
    }

    public void create() {
        User user = new User("U01", "123", "tco@gmail.com", "Tèo", false); 
        try {
            em.getTransaction().begin();
            em.persist(user); 
            em.getTransaction().commit();
            System.out.println("CREATE: User U01 thành công.");
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.err.println("CREATE: User U01 thất bại (ID đã tồn tại?).");
        }
    }

    public void update() {
        User user = em.find(User.class, "U01");
        
        if (user != null) {
            
            user.setFullname("Nguyễn Văn Tèo");
            user.setEmail("teonv@gmail.com");
            
            try {
                em.getTransaction().begin();
                em.merge(user); 
                em.getTransaction().commit();
                System.out.println(" UPDATE: User U01 thành công.");
            } catch (Exception e) {
                em.getTransaction().rollback();
                System.err.println(" UPDATE: Lỗi, đã Rollback.");
                e.printStackTrace();
            }
        } else {
            System.err.println("User U01 không tồn tại để update.");
        }
    }

    public void deleteById() {

        User user = em.find(User.class, "U01");
        
        if (user != null) {
            try {
                em.getTransaction().begin();
                em.remove(user); 
                em.getTransaction().commit();
                System.out.println("DELETE: User U01 thành công.");
            } catch (Exception e) {
                em.getTransaction().rollback();
                System.err.println("DELETE: Lỗi, đã Rollback.");
            }
        } else {
            System.err.println("User U01 không tồn tại để xóa.");
        }
    }
    
    public void close() {
        if (em != null) em.close();
        if (factory != null) factory.close();
    }
    // bai 3
    public void findUserEmails() {
        
        String jpql = "SELECT o FROM User o WHERE o.email LIKE :search AND o.admin = :role";

        TypedQuery<User> query = em.createQuery(jpql, User.class);

        query.setParameter("search", "%@fpt.edu.vn"); 
        
        query.setParameter("role", false); 

        List<User> list = query.getResultList();

        System.out.println("\n--- BÀI 3: KẾT QUẢ USER KHÔNG PHẢI ADMIN (@fpt.edu.vn) ---");
        if (list.isEmpty()) {
            System.out.println("Không tìm thấy user thỏa mãn điều kiện.");
            return;
        }
        
        list.forEach(user -> {
            System.out.println("Họ tên: " + user.getFullname() + ", Email: " + user.getEmail());
        });
    }
 // BÀI 4: TRUY VẤN PHÂN TRANG (Pagination)
    public void paginateUsers(int pageNumber, int pageSize) {
        String jpql = "SELECT o FROM User o ORDER BY o.id"; 
        TypedQuery<User> query = em.createQuery(jpql, User.class);

        int firstResult = pageNumber * pageSize; 

        query.setFirstResult(firstResult);

        query.setMaxResults(pageSize);

        List<User> list = query.getResultList();

        System.out.println("\n--- BÀI 4: KẾT QUẢ TRUY VẤN PHÂN TRANG ---");
        System.out.println("Truy vấn Trang: " + (pageNumber + 1) + ", Kích thước: " + pageSize + " (Bắt đầu từ index: " + firstResult + ")");
        if (list.isEmpty()) {
            System.out.println("Không có dữ liệu ở trang này. (Cần > 10 user để thấy trang 3)");
            return;
        }

        int count = firstResult + 1;
        for (User user : list) {
            System.out.println((count++) + ". ID: " + user.getId() + ", Tên: " + user.getFullname());
        }
    }
}