package com.poly.dao;

import com.poly.entity.User;
import java.util.List;

/**
 * Giao diện định nghĩa các chức năng truy xuất dữ liệu (DAO) cho đối tượng User.
 * Đây là chuẩn mực cho tất cả các hoạt động CRUD cơ bản.
 */
public interface UserDAO {

    /**Truy vấn tất cả User*/
    List<User> findAll();

    /**Truy vấn User theo mã (ID)*/
    User findById(String id);
    
    /**Truy vấn User theo ID hoặc Email (Mới)*/
    User findByIdOrEmail(String id, String email); // <-- PHƯƠNG THỨC MỚI

    /**Thêm mới một User*/
    void create(User item);

    /**Cập nhật thông tin một User*/
    void update(User item);

    /**Xóa User theo mã (ID)*/
    void deleteById(String id);
}