package com.poly.dao.impl;

import com.poly.dao.ShareDAO;
import com.poly.entity.Share;
import com.poly.util.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.Query;
import java.util.List;

public class ShareDAOImpl extends AbstractDAOImpl<Share, Long> implements ShareDAO {

    // ... (Các phương thức đã có) ...

    /**
     * Tìm Video được chia sẻ trong năm 2024 và sắp xếp theo thời gian (Yêu cầu 5).
     */
    public List<Share> findSharedIn2024() {
        EntityManager em = XJPA.getEntityManager();
        try {
            // Dùng hàm JPQL YEAR()
            String jpql = "SELECT s FROM Share s WHERE YEAR(s.shareDate) = 2024 ORDER BY s.shareDate DESC";
            TypedQuery<Share> query = em.createQuery(jpql, Share.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
    
    /**
     * Truy vấn thống kê tổng hợp (Yêu cầu 6 đã có)
     * @return List<Object[]>: [Video Title, Count, MinDate, MaxDate]
     */
    @SuppressWarnings("unchecked")
    public List<Object[]> findShareReport() {
        EntityManager em = XJPA.getEntityManager();
        
        String jpql = "SELECT s.video.title, COUNT(s.id), MIN(s.shareDate), MAX(s.shareDate) FROM Share s GROUP BY s.video.title ORDER BY COUNT(s.id) DESC";
        
        Query query = em.createQuery(jpql); 
        
        List<Object[]> report = query.getResultList();
        em.close();
        return report;
    }
}