package com.poly.util;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class XJPA {


    private static EntityManagerFactory factory;


    static {

        try {
            factory = Persistence.createEntityManagerFactory("PolyOE");
        } catch (Exception e) {

            System.err.println("FATAL: Cannot initialize EntityManagerFactory for PolyOE.");
            e.printStackTrace();
            throw new ExceptionInInitializerError(e);
        }
    }

    public static EntityManager getEntityManager(){

        return factory.createEntityManager();
    }
    
    public static void shutdown() {
        if (factory != null && factory.isOpen()) {
            factory.close();
        }
    }
}