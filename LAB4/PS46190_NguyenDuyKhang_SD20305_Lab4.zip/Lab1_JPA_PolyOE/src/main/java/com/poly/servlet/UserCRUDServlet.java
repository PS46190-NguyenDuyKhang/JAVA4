package com.poly.servlet;

import com.poly.dao.UserDAO; // ⬅️ THÊM DÒNG NÀY
import com.poly.dao.impl.UserDAOImpl; // ⬅️ THÊM DÒNG NÀY
import com.poly.entity.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import org.apache.commons.beanutils.BeanUtils;

@WebServlet({
    "/user/crud/index",
    "/user/crud/edit/*",
    "/user/crud/create",
    "/user/crud/update",
    "/user/crud/delete",
    "/user/crud/reset"
})
public class UserCRUDServlet extends HttpServlet {
    
    // Khai báo DAO instance
    UserDAO dao = new UserDAOImpl(); 
    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8"); 
        
        User form = new User();
        
        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
        
        String message = "Enter user information";
        String path = req.getServletPath();
        
        try {
            if (path.contains("edit")) {
                String id = req.getPathInfo().substring(1); 
                form = dao.findById(id); 
                message = "Editing User: " + id;
                if (form == null) message = "Error: User " + id + " not found!";
                
            } else if (path.contains("create")) {
                dao.create(form); 
                message = "Created User: " + form.getFullname() + " successfully!";
                form = new User();
            } else if (path.contains("update")) {
                dao.update(form); 
                message = "Updated User: " + form.getId() + " successfully!";
            } else if (path.contains("delete")) {
                dao.deleteById(form.getId()); 
                message = "Deleted User: " + form.getId() + " successfully!";
                form = new User();
            } else if (path.contains("reset")) {
                message = "Form reset!";
                form = new User();
            }
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
        }
        
        List list = dao.findAll(); 
        
        req.setAttribute("message", message);
        req.setAttribute("user", form); 
        req.setAttribute("users", list); 
        
        resp.setCharacterEncoding("UTF-8");
        req.getRequestDispatcher("/pages/user-crud.jsp").forward(req, resp);
    }
}