package com.oe.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.oe.dao.FavoriteDao;
import com.oe.dao.VideoDao;
import com.oe.entity.Favorite;
import com.oe.entity.User;
import com.oe.entity.Video;

@WebServlet("/video/*")
public class VideoServlet extends HttpServlet {

    private final VideoDao videoDao = new VideoDao();
    private final FavoriteDao favoriteDao = new FavoriteDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        if ("/detail".equals(path)) {
            showDetail(req, resp);
            return;
        }

        if ("/all".equals(path)) {
            showAll(req, resp);
            return;
        }

        if ("/search".equals(path)) {
            search(req, resp);
            return;
        }

        resp.sendError(404);
    }

    // =====================================================================================
    //                                 TRANG CHI TIẾT VIDEO
    // =====================================================================================
    private void showDetail(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        String id = req.getParameter("id");

        if (id == null || id.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        id = id.trim();
        Video video = videoDao.findById(id);

        if (video == null) {
            resp.sendError(404, "Video không tồn tại");
            return;
        }

        // TĂNG VIEW
        try {
            video.setViews(video.getViews() + 1);
            videoDao.update(video);
        } catch (Exception e) {
            System.out.println("Lỗi update view: " + e.getMessage());
        }

        // KIỂM TRA USER ĐÃ LIKE CHƯA
        User user = (User) req.getSession().getAttribute("user");

        boolean liked = false;
        if (user != null) {
            Favorite f = favoriteDao.findByUserAndVideo(user, video);
            liked = (f != null);
        }

        req.setAttribute("liked", liked);

        // đề xuất video
        List<Video> allVideos = videoDao.findAll()
                .stream()
                .filter(v -> !v.getId().equals(video.getId()))
                .collect(Collectors.toList());

        Collections.shuffle(allVideos);
        List<Video> suggest = allVideos.stream().limit(10).collect(Collectors.toList());

        req.setAttribute("video", video);
        req.setAttribute("suggest", suggest);

        req.getRequestDispatcher("/WEB-INF/views/video/detail.jsp").forward(req, resp);
    }

    // =====================================================================================
    //                                  TRANG TẤT CẢ VIDEO
    // =====================================================================================
    private void showAll(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Video> list = videoDao.findAll();

        int pageSize = 12;
        int page = 1;

        try {
            String p = req.getParameter("page");
            if (p != null) page = Integer.parseInt(p);
        } catch (Exception ignored) {}

        int totalItems = list.size();
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);

        if (totalPages < 1) totalPages = 1;
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        int start = (page - 1) * pageSize;
        int end = Math.min(start + pageSize, totalItems);

        List<Video> pageData = list.subList(start, end);

        req.setAttribute("videos", pageData);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);

        req.getRequestDispatcher("/WEB-INF/views/video/all.jsp").forward(req, resp);
    }

    // =====================================================================================
    //                                  TÌM KIẾM VIDEO
    // =====================================================================================
    private void search(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String keyword = req.getParameter("keyword");

        if (keyword == null || keyword.trim().isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/video/all");
            return;
        }

        keyword = keyword.trim();

        List<Video> list = videoDao.search(keyword);

        req.setAttribute("videos", list);
        req.setAttribute("currentPage", 1);
        req.setAttribute("totalPages", 1);
        req.setAttribute("keyword", keyword);

        req.getRequestDispatcher("/WEB-INF/views/video/all.jsp").forward(req, resp);
    }

}
