package com.oe.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Videos")
public class Video {

    @Id
    @Column(length = 50)
    private String id;              // Youtube ID

    @Column(nullable = false, length = 255)
    private String title;

    @Column(length = 255)
    private String poster;          // đường dẫn hình

    @Column(nullable = false)
    private Integer views = 0;

    @Column(columnDefinition = "NVARCHAR(MAX)")
    private String description;

    @Column(nullable = false)
    private Boolean active = true;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public Integer getViews() {
		return views;
	}

	public void setViews(Integer views) {
		this.views = views;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

    // getters & setters
}
