package com.oe.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.oe.dao.*;
import com.oe.entity.*;
import com.oe.util.YoutubeUtil;

@WebServlet("/admin/*")
public class AdminServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final UserDao userDao = new UserDao();
    private final VideoDao videoDao = new VideoDao();
    private final FavoriteDao favoriteDao = new FavoriteDao();
    private final ShareDao shareDao = new ShareDao();


    // =====================================================================================
    //                                      GET
    // =====================================================================================
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        if (path == null || "/".equals(path) || "/home".equals(path)) {
            req.getRequestDispatcher("/WEB-INF/views/admin/home.jsp").forward(req, resp);
            return;
        }

        switch (path) {

            // =============================================
            //                VIDEO PAGE
            // =============================================
            case "/videos": {

                String action = req.getParameter("action");

                if ("edit".equals(action)) {
                    String id = req.getParameter("id");
                    Video v = videoDao.findById(id);

                    if (v != null) {
                        req.setAttribute("editVideo", v);
                        req.setAttribute("editVideoUrl", "https://youtu.be/" + v.getId());
                    } else {
                        req.setAttribute("error", "Video không tồn tại!");
                    }
                }

                loadVideoPage(req, resp);
                break;
            }

            // =============================================
            //                USERS PAGE
            // =============================================
            case "/users": {

                String action = req.getParameter("action");

                if ("edit".equals(action)) {
                    String id = req.getParameter("id");
                    User u = userDao.findById(id);

                    if (u != null) {
                        req.setAttribute("editUser", u);
                    } else {
                        req.setAttribute("error", "User không tồn tại!");
                    }
                }

                loadUserPage(req, resp);
                break;
            }

            // =============================================
            //                REPORTS PAGE
            // =============================================
            case "/reports": {

                var pg = paginate(req, videoDao.reportFavoriteCount(), 10);

                req.setAttribute("reportFavorites", pg.get("data"));
                req.setAttribute("currentPage", pg.get("currentPage"));
                req.setAttribute("totalPages", pg.get("totalPages"));

                req.getRequestDispatcher("/WEB-INF/views/admin/reports.jsp").forward(req, resp);
                break;
            }

            default:
                resp.sendError(404);
        }
    }


    // =====================================================================================
    //                                      POST
    // =====================================================================================
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();
        if (path == null) {
            resp.sendError(404);
            return;
        }

        switch (path) {
            case "/videos":
                saveVideo(req, resp);
                break;

            case "/users":
                saveUser(req, resp);
                break;

            default:
                resp.sendError(404);
        }
    }


    // =====================================================================================
    //                                      VIDEO CRUD
    // =====================================================================================
    private void saveVideo(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String action = req.getParameter("action");

        // -------- DELETE --------
        if ("delete".equals(action)) {

            String id = req.getParameter("id");
            Video v = videoDao.findById(id);

            if (v != null) {
                videoDao.delete(id);
            }

            resp.sendRedirect(req.getContextPath() + "/admin/videos");
            return;
        }


        // -------- CREATE / UPDATE --------
        String url = req.getParameter("url");

        if (url == null || url.isBlank()) {
            req.setAttribute("error", "Bạn phải nhập link YouTube!");
            loadVideoPage(req, resp);
            return;
        }

        String videoId = YoutubeUtil.extractVideoId(url.trim());
        if (videoId == null) {
            req.setAttribute("error", "Link YouTube không hợp lệ!");
            loadVideoPage(req, resp);
            return;
        }

        Video video = videoDao.findById(videoId);
        boolean isCreate = (video == null);

        if (isCreate) {
            video = new Video();
            video.setId(videoId);
        }

        try {
            Map<String, String[]> map = new HashMap<>(req.getParameterMap());
            map.remove("url");
            map.remove("id");

            BeanUtils.populate(video, map);

            if (video.getPoster() == null || video.getPoster().isBlank()) {
                video.setPoster("https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg");
            }

            if (isCreate) videoDao.create(video);
            else videoDao.update(video);

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi xử lý dữ liệu: " + e.getMessage());
            loadVideoPage(req, resp);
            return;
        }

        resp.sendRedirect(req.getContextPath() + "/admin/videos");
    }


    private void loadVideoPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        var pg = paginate(req, videoDao.findAll(), 10);

        req.setAttribute("videos", pg.get("data"));
        req.setAttribute("currentPage", pg.get("currentPage"));
        req.setAttribute("totalPages", pg.get("totalPages"));

        req.getRequestDispatcher("/WEB-INF/views/admin/videos.jsp").forward(req, resp);
    }


    // =====================================================================================
    //                                      USER CRUD
    // =====================================================================================
    private void saveUser(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String action = req.getParameter("action");

        // -------- DELETE --------
        if ("delete".equals(action)) {

            String id = req.getParameter("id");
            User u = userDao.findById(id);

            if (u != null) {
                userDao.delete(id);
            }

            resp.sendRedirect(req.getContextPath() + "/admin/users");
            return;
        }


        // -------- CREATE / UPDATE --------
        String id = req.getParameter("id");

        if (id == null || id.isBlank()) {
            req.setAttribute("error", "ID user không được để trống!");
            loadUserPage(req, resp);
            return;
        }

        id = id.trim();

        User user = userDao.findById(id);
        boolean isCreate = (user == null);

        if (isCreate) {
            user = new User();
            user.setId(id);
        }

        try {
            BeanUtils.populate(user, req.getParameterMap());

            if (!isCreate) {
                String pass = req.getParameter("password");
                if (pass == null || pass.isBlank()) {
                    user.setPassword(userDao.findById(id).getPassword());
                }
            }

            if (isCreate) userDao.create(user);
            else userDao.update(user);

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi xử lý user: " + e.getMessage());
            loadUserPage(req, resp);
            return;
        }

        resp.sendRedirect(req.getContextPath() + "/admin/users");
    }


    private void loadUserPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        var pg = paginate(req, userDao.findAll(), 10);

        req.setAttribute("users", pg.get("data"));
        req.setAttribute("currentPage", pg.get("currentPage"));
        req.setAttribute("totalPages", pg.get("totalPages"));

        req.getRequestDispatcher("/WEB-INF/views/admin/users.jsp").forward(req, resp);
    }


    // =====================================================================================
    //                                      PAGINATION
    // =====================================================================================
    private <T> Map<String, Object> paginate(HttpServletRequest req, List<T> list, int pageSize) {

        int page = 1;
        try {
            String p = req.getParameter("page");
            if (p != null) page = Integer.parseInt(p);
        } catch (Exception ignored) {}

        int totalItems = list.size();
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);

        if (totalPages < 1) totalPages = 1;
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        int start = (page - 1) * pageSize;
        if (start < 0) start = 0;
        if (start > totalItems) start = totalItems;

        int end = Math.min(start + pageSize, totalItems);
        if (end < start) end = start;

        Map<String, Object> result = new HashMap<>();
        result.put("data", list.subList(start, end));
        result.put("currentPage", page);
        result.put("totalPages", totalPages);

        return result;
    }

}
