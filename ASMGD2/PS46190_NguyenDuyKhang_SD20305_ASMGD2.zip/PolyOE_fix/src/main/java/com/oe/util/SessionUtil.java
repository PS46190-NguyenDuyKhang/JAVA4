package com.oe.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class SessionUtil {

    public static void set(HttpServletRequest req, String name, Object value) {
        HttpSession session = req.getSession();
        session.setAttribute(name, value);
    }

    public static Object get(HttpServletRequest req, String name) {
        HttpSession session = req.getSession(false);
        return (session == null) ? null : session.getAttribute(name);
    }

    public static void invalidate(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session != null) session.invalidate();
    }
}
