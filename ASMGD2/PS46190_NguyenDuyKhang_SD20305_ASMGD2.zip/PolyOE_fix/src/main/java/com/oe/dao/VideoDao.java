package com.oe.dao;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import com.oe.entity.Video;
import com.oe.util.HibernateUtil;

public class VideoDao extends AbstractDao<Video, String> {

    public VideoDao() {
        super(Video.class);
    }

    public List<Video> findPage(int page, int size) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "SELECT v FROM Video v WHERE v.active = true ORDER BY v.views DESC",
                    Video.class)
                    .setFirstResult((page - 1) * size)
                    .setMaxResults(size)
                    .getResultList();
        }
    }
    public List<Video> search(String keyword) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
                SELECT v FROM Video v
                WHERE v.title LIKE :kw
                   OR v.id LIKE :kw
                   AND v.active = true
                ORDER BY v.views DESC
            """;

            return session.createQuery(hql, Video.class)
                    .setParameter("kw", "%" + keyword + "%")
                    .getResultList();
        }
    }


    public long count() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "SELECT COUNT(v) FROM Video v", Long.class)
                    .getSingleResult();
        }
    }

    public List<Object[]> reportFavoriteCount() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String jpql = """
                SELECT v.title, COUNT(f.id), MIN(f.shareDate), MAX(f.shareDate)
                FROM Favorite f 
                JOIN f.video v
                GROUP BY v.title
            """;
            return session.createQuery(jpql, Object[].class).getResultList();
        }
    }

    
    public List<Video> randomVideos(int limit) {
        List<Video> list = findAll();       // lấy toàn bộ
        Collections.shuffle(list);          // xáo trộn ngẫu nhiên

        return list.stream()
                .limit(limit)
                .collect(Collectors.toList());
    }

}
