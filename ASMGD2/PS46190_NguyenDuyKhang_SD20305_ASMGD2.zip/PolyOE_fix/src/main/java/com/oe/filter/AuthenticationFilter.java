package com.oe.filter;

import java.io.IOException;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

import com.oe.entity.User;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req  = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri  = req.getRequestURI();
        String ctx  = req.getContextPath();
        String path = uri.substring(ctx.length()); // 🔥 chuẩn nhất

        User user = (User) req.getSession().getAttribute("user");

        // =============================
        // 0. PUBLIC PATH (không chặn)
        // =============================
        boolean isPublic =
                   path.startsWith("/user/login")
                || path.startsWith("/user/register")
                || path.startsWith("/user/forgot")
                || path.startsWith("/home")
                || path.startsWith("/video")
                || path.startsWith("/assets")
                || path.equals("/")
                || path.startsWith("/favicon");

        if (isPublic) {
            chain.doFilter(request, response);
            return;
        }

        // =============================
        // 1. Yêu cầu login cho admin + favorite + share
        // =============================
        boolean mustLogin =
                   path.startsWith("/admin")
                || path.startsWith("/favorite")
                || path.startsWith("/share");

        if (mustLogin && user == null) {
            req.getSession().setAttribute("security-uri", uri);
            resp.sendRedirect(ctx + "/user/login");
            return; // 🔥 tránh chạy tiếp
        }

        // =============================
        // 2. Yêu cầu quyền ADMIN
        // =============================
        if (path.startsWith("/admin")) {
            if (user == null || !Boolean.TRUE.equals(user.getAdmin())) {
                resp.sendRedirect(ctx + "/home?error=notadmin");
                return;
            }
        }

        // =============================
        // OK, tiếp tục
        // =============================
        chain.doFilter(request, response);
    }
}
