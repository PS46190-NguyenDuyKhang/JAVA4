package com.oe.util;

import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

public class EmailUtil {

    private static final Properties PROPS = new Properties();

    static {
        try {
            PROPS.load(EmailUtil.class.getClassLoader()
                         .getResourceAsStream("mail.properties"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void send(String to, String subject, String content) {
        try {
            String username = PROPS.getProperty("mail.username");
            String password = PROPS.getProperty("mail.password");

            Session session = Session.getInstance(PROPS,
                    new Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                        }
                    });

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(to));
            message.setSubject(subject);
            message.setText(content);

            Transport.send(message);
        } catch (Exception e) {
            throw new RuntimeException("Lỗi gửi email", e);
        }
    }
}
