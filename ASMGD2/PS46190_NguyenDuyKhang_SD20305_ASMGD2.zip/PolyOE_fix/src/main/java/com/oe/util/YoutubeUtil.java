package com.oe.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YoutubeUtil {

    // Regex nhận mọi loại link YouTube
    private static final String YT_REGEX =
            "(?<=v=)[^&]+|(?<=be/)[^?]+|(?<=embed/)[^?]+|(?<=shorts/)[^?]+";

    private static final Pattern pattern = Pattern.compile(YT_REGEX);

    /**
     * Trích videoId từ các dạng link YouTube hợp lệ
     */
    public static String extractVideoId(String url) {
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    /**
     * Tạo link embed
     */
    public static String buildEmbedUrl(String videoId) {
        if (videoId == null) return null;
        return "https://www.youtube.com/embed/" + videoId;
    }
}
