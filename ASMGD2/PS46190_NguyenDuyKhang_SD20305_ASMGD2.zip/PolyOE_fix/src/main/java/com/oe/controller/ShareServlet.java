package com.oe.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import com.oe.dao.*;
import com.oe.entity.*;
import com.oe.util.*;

@WebServlet("/share")
public class ShareServlet extends HttpServlet {

    private final ShareDao shareDao = new ShareDao();
    private final VideoDao videoDao = new VideoDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String videoId = req.getParameter("id");
        if (videoId == null) {
            resp.sendError(404);
            return;
        }

        Video video = videoDao.findById(videoId);
        if (video == null) {
            resp.sendError(404, "Video không tồn tại!");
            return;
        }

        req.setAttribute("video", video);
        req.getRequestDispatcher("/WEB-INF/views/video/share.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(req, "user");
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/user/login");
            return;
        }

        String videoId = req.getParameter("id");
        String emails = req.getParameter("emails");

        Video video = videoDao.findById(videoId);
        if (video == null) {
            resp.sendError(404, "Video không tồn tại!");
            return;
        }

        // Lưu share
        Share share = new Share();
        share.setUser(user);
        share.setVideo(video);
        share.setEmails(emails);
        shareDao.create(share);

        // Tách email sạch sẽ
        String[] list = emails.split("[,;]");
        for (int i = 0; i < list.length; i++) {
            list[i] = list[i].trim();
        }

        // Tạo link đúng chuẩn
        String link = req.getRequestURL().toString()
                .replace("/share", "/video/detail?id=" + videoId);

        // Gửi mail
        String subject = user.getFullname() + " đã chia sẻ video cho bạn!";
        String body = "Link video: " + link;

        for (String to : list) {
            if (!to.isEmpty()) {
                EmailUtil.send(to, subject, body);
            }
        }

        // Redirect để tránh gửi mail lần nữa khi refresh
        resp.sendRedirect(req.getContextPath() + "/video/detail?id=" + videoId + "&share=success");
    }
}

