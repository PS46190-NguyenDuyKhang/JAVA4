package com.oe.controller;

import java.io.IOException;

import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.oe.dao.UserDao;
import com.oe.entity.User;
import com.oe.util.CookieUtil;
import com.oe.util.EmailUtil;
import com.oe.util.SessionUtil;

@WebServlet("/user/*")
public class UserServlet extends HttpServlet {

    private final UserDao userDao = new UserDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        if (path == null || path.equals("/") || path.equals("/login")) {
            // AUTO LOGIN USING COOKIE
            autoLogin(req, resp);

            // load email & pwd from cookie
            req.setAttribute("email", CookieUtil.get("email", req));
            req.setAttribute("password", CookieUtil.get("password", req));

            req.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(req, resp);
            return;
        }

        switch (path) {
            case "/register":
                req.getRequestDispatcher("/WEB-INF/views/user/register.jsp").forward(req, resp);
                break;

            case "/forgot":
                req.getRequestDispatcher("/WEB-INF/views/user/forgot-password.jsp").forward(req, resp);
                break;

            case "/change-password":
                req.getRequestDispatcher("/WEB-INF/views/user/change-password.jsp").forward(req, resp);
                break;

            case "/edit-profile":
                req.getRequestDispatcher("/WEB-INF/views/user/edit-profile.jsp").forward(req, resp);
                break;

            case "/logout":
                SessionUtil.invalidate(req);
                CookieUtil.remove("email", resp);
                CookieUtil.remove("password", resp);
                resp.sendRedirect(req.getContextPath() + "/home");
                break;

            default:
                resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        switch (path) {
            case "/login":
                login(req, resp);
                break;

            case "/register":
                register(req, resp);
                break;

            case "/forgot":
                forgot(req, resp);
                break;

            case "/change-password":
                changePassword(req, resp);
                break;

            case "/edit-profile":
                editProfile(req, resp);
                break;

            default:
                resp.sendError(404);
        }
    }

    // ==========================================================
    // LOGIN (EMAIL + PASSWORD + REMEMBER ME)
    // ==========================================================
    private void login(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String pw = req.getParameter("password");
        String remember = req.getParameter("remember");

        User user = userDao.findByEmailAndPassword(email, pw);

        if (user == null) {
            req.setAttribute("error", "Sai email hoặc mật khẩu!");
            req.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(req, resp);
            return;
        }

        // Save session user
        SessionUtil.set(req, "user", user);

        // Remember me
        if ("on".equals(remember)) {
            CookieUtil.add("email", email, 30, resp);
            CookieUtil.add("password", pw, 30, resp);
        } else {
            CookieUtil.remove("email", resp);
            CookieUtil.remove("password", resp);
        }

        // Redirect admin or user
        if (Boolean.TRUE.equals(user.getAdmin())) {
            resp.sendRedirect(req.getContextPath() + "/admin/home");
        } else {
            resp.sendRedirect(req.getContextPath() + "/home");
        }
    }

    // AUTO LOGIN IF COOKIE EXISTS
    private void autoLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String email = CookieUtil.get("email", req);
        String pw = CookieUtil.get("password", req);

        if (email != null && pw != null) {
            User user = userDao.findByEmailAndPassword(email, pw);
            if (user != null) {
                SessionUtil.set(req, "user", user);

                if (Boolean.TRUE.equals(user.getAdmin())) {
                    resp.sendRedirect(req.getContextPath() + "/admin/home");
                } else {
                    resp.sendRedirect(req.getContextPath() + "/home");
                }
                return;
            }
        }
    }

    // ==========================================================
    // REGISTER
    // ==========================================================
    private void register(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = new User();

        try {
            BeanUtils.populate(user, req.getParameterMap());

            user.setAdmin(false); // ensure normal user

            userDao.create(user);

            req.setAttribute("message", "Đăng ký thành công!");
            req.getRequestDispatcher("/WEB-INF/views/user/login.jsp").forward(req, resp);

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/views/user/register.jsp").forward(req, resp);
        }
    }

    // ==========================================================
    // FORGOT PASSWORD
    // ==========================================================
    private void forgot(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        User user = userDao.findByEmail(email);

        if (user == null) {
            req.setAttribute("error", "Email không tồn tại!");
            req.getRequestDispatcher("/WEB-INF/views/user/forgot-password.jsp").forward(req, resp);
            return;
        }

        EmailUtil.send(email, "Reset Password",
                "Mật khẩu của bạn là: " + user.getPassword());

        req.setAttribute("message", "Đã gửi mật khẩu qua email!");
        req.getRequestDispatcher("/WEB-INF/views/user/forgot-password.jsp").forward(req, resp);
    }

    // ==========================================================
    // CHANGE PASSWORD
    // ==========================================================
    private void changePassword(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(req, "user");

        String current = req.getParameter("current");
        String newpw = req.getParameter("password");
        String confirm = req.getParameter("confirm");

        if (!user.getPassword().equals(current)) {
            req.setAttribute("error", "Sai mật khẩu hiện tại!");
        } else if (!newpw.equals(confirm)) {
            req.setAttribute("error", "Mật khẩu xác nhận không trùng!");
        } else {
            user.setPassword(newpw);
            userDao.update(user);
            req.setAttribute("message", "Đổi mật khẩu thành công!");
        }

        req.getRequestDispatcher("/WEB-INF/views/user/change-password.jsp").forward(req, resp);
    }

    // ==========================================================
    // EDIT PROFILE
    // ==========================================================
    private void editProfile(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) SessionUtil.get(req, "user");

        try {
            BeanUtils.populate(user, req.getParameterMap());

            user.setAdmin(user.getAdmin()); // avoid admin changes

            userDao.update(user);

            req.setAttribute("message", "Cập nhật thành công!");

        } catch (Exception e) {
            req.setAttribute("error", "Lỗi: " + e.getMessage());
        }

        req.getRequestDispatcher("/WEB-INF/views/user/edit-profile.jsp").forward(req, resp);
    }
}
