package com.oe.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {

    private static final SessionFactory FACTORY = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            StandardServiceRegistry registry = 
                new StandardServiceRegistryBuilder()
                    .configure("hibernate.cfg.xml")
                    .build();

            return new MetadataSources(registry)
                    
                    .addAnnotatedClass(com.oe.entity.User.class)
                    .addAnnotatedClass(com.oe.entity.Video.class)
                    .addAnnotatedClass(com.oe.entity.Favorite.class)
                    .addAnnotatedClass(com.oe.entity.Share.class)
                    
                    .buildMetadata()
                    .buildSessionFactory();

        } catch (Exception e) {
            throw new RuntimeException("Lỗi tạo SessionFactory", e);
        }
    }

    public static SessionFactory getSessionFactory() {
        return FACTORY;
    }
}
