﻿USE master
GO

-- Xóa database cũ nếu có để tránh lỗi trùng lặp
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'PolyOE3')
DROP DATABASE PolyOE
GO

CREATE DATABASE PolyOE3
GO
USE PolyOE3
GO

-- 1. TẠO BẢNG
CREATE TABLE Video(
	id VARCHAR(255) PRIMARY KEY,
	title NVARCHAR(255) NOT NULL,
	poster VARCHAR(MAX) NOT NULL,
	views INT DEFAULT 0,
	[description] NVARCHAR(MAX) NOT NULL,
	active BIT DEFAULT 1
)
GO

CREATE TABLE Users(
	id VARCHAR(255) PRIMARY KEY,
	[password] VARCHAR(255) NOT NULL,
	email VARCHAR(50) NOT NULL,
	fullname NVARCHAR(255) NOT NULL,
	[admin] BIT DEFAULT 0
)
GO

CREATE TABLE Favorite(
	id INT IDENTITY(1,1) PRIMARY KEY,
	[user_id] VARCHAR(255) FOREIGN KEY REFERENCES Users(id),
	video_id VARCHAR(255) FOREIGN KEY REFERENCES Video(id),
	share_date DATE DEFAULT GETDATE() -- Ngày like
)
GO

CREATE TABLE Share(
	id INT IDENTITY(1,1) PRIMARY KEY,
	[user_id] VARCHAR(255) FOREIGN KEY REFERENCES Users(id),
	video_id VARCHAR(255) FOREIGN KEY REFERENCES Video(id),
	emails VARCHAR(50) NOT NULL,
	share_date DATE DEFAULT GETDATE()
)
GO

-- 2. THÊM DỮ LIỆU USERS
INSERT INTO Users (id, [password], email, fullname, [admin]) VALUES 
(N'admin', N'123', N'admin@poly.edu.vn', N'Nguyễn Văn Quản Trị', 1),
(N'user01', N'123', N'nguyenvana@gmail.com', N'Nguyễn Văn A', 0),
(N'user02', N'123', N'tranthib@gmail.com', N'Trần Thị B', 0),
(N'teofpt', N'123', N'teonv@fpt.edu.vn', N'Nguyễn Văn Tèo', 0);
GO

-- 3. THÊM DỮ LIỆU VIDEO (QUAN TRỌNG: ID LÀ MÃ YOUTUBE, POSTER LÀ TÊN FILE ẢNH)
-- Mình đã map các ảnh có trong thư mục images của bạn vào các video này
INSERT INTO Video (id, title, poster, views, [description], active) VALUES
('V001', N'LÝ DO TẠI ANH – Sơn (demo)', 'JIrPrfaYz0Y', 1000, N'Demo tâm sự nhẹ nhàng về chuyện tình cảm.', 1),
('V002', N'Thấp Drill Tự Do – LBI (Gazz Milo) | Jerk Drill Type Beat','g5idrebJVQE', 500, N'Beat drill hiện đại dành cho freestyle.', 1),
('V003', N'thap trap tu do (remix) – Ly ti ca prod. tyronee', 'OULRkydnOyM', 2000, N'Remix trap mạnh mẽ, vibe đường phố.', 1),
('V004', N'Si Mê You – Obito | Official Music Videorắng Remix', 'U8VQmgHMngk', 1500, N'Ca khúc ngọt ngào nói về cảm xúc si mê.', 1),
('V005', N'Kentaro – 空想 (feat. 空想夢) Official Lyric Video', 'AjYHDs63jrk', 800, N'Nhạc Nhật lãng mạn, mang màu sắc mơ mộng.', 1),
('V006', N'ETERNAL ULTRAFUNK! – HIKIM', 'OJgQGJuihtA', 1200, N'Track ultrafunk năng lượng cao.', 1),
('V007', N'NGÀY MAI LÀ TƯƠNG LAI (feat. Obito) – RAP VIỆT Topic', 'hvrPWTgc9kY', 2500, N'Bài rap truyền cảm hứng về tương lai.', 1),
('V008', N'Obito – Đầu Đường Xó Chợ ft. Lăng LD', 'xRL2BspFnOs', 900, N'Kể về cuộc sống đường phố đầy góc khuất.', 1),
('V009', N'New Jeans Jersey Remix SLOWED – (Jiandro x DXKrai)', 'kxuyoJZ5S4w', 1700, N'Remix Jersey Club phiên bản slowed chill.', 1),
('V010', N'Saka Trương Tuyền - Tình Yêu Bất Diệt', 'CsrsR_sC2jE', 3000, N'Câu chuyện tình cảm đầy phức tạp.', 1),
('V011', N'Complicated – Obito | Lyrics Video', '83aD3RncuPk', 1300, N'Remix tổng hợp các giai điệu của Obito.', 1),
('V012', N'Playlist Rmx Obito (Music Video) | Raytis Music® x Underdogofrly', 'euyhxqC8Uq0', 2800, N'Nói về cảm xúc và tâm trạng tuổi 16.', 1),
('V013', N'Obito – 16', 'Bn9IJu7c3FA', 1100, N'Nỗi niềm về những điều còn dang dở.', 1),
('V014', N'Obito – Chưa Xong', 'I8HYN3WsuOQ', 1900, N'Tình yêu vô điều kiện, yêu không lý do.', 1),
('V015', N'Obito – Vô Điều Kiện', '4DVKNbphJlE', 3500, N'Thông điệp sống thoải mái, không lo nghĩ.', 1),
('V016', N'KHÔNG VẤN ĐỀ – RHYDER ft. COOLKID (Prod. Long Nhat)', 'AFaSvA6eVKk', 2200, N'Phiên bản slowed mang vibe chill buồn.', 1),
('V017', N'NO BAD4LO (Slowed) – SLK.A', 'K1-C7paZxp8', 1400, N'Nỗi hoài nghi sau những tổn thương tình cảm..', 1),
('V018', N'CHẲNG TIN VÀO TÌNH YÊU – RHYDER ft. COOLKID (Prod. Dũng DJ)', 'Jri-Pajungo', 1600, N'Cảm xúc day dứt và suy tư trong tình yêu.', 1),
('V019', N'SAU CĂN SƯY – RHYDER | Official Music Video', '936y4HMimhg', 900, N'Diễn tả cảm giác lạc lõng và cô đơn.', 1),
('V020', N'LOST – Obito (OFFICIAL MV)', 'ealfjTQEI4Q', 2700, N'Tình yêu tăm tối nhưng cuốn hút.', 1);
GO

-- 4. THÊM DỮ LIỆU FAVORITE (Sửa lại ID cho khớp với bảng Video mới)
INSERT INTO Favorite ([user_id], video_id, share_date) VALUES 
(N'user01', 'V001', '2023-11-20'), -- User 1 like Video CS2
(N'user01', 'V002', '2023-11-21'), -- User 1 like Video Truyện ma
(N'user02', 'V001', '2023-11-22'), -- User 2 like Video CS2
(N'teofpt', 'V003', '2023-11-23'), -- Teo like Video DJ
(N'admin', 'V004', GETDATE());    -- Admin like Video Billiards
GO

-- 5. THÊM DỮ LIỆU SHARE (Sửa lại ID cho khớp)
INSERT INTO Share ([user_id], video_id, emails, share_date) VALUES 
(N'user01', 'V001', N'banbe@gmail.com', '2023-11-20'),
(N'user01', 'V002', N'thaygiao@fpt.edu.vn', '2023-11-21'),
(N'teofpt', 'V003', N'crush@yahoo.com', GETDATE());
GO