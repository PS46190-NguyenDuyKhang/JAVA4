package utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class XJPA {
	private static SessionFactory SESSION_FACTORY = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		try {
			// Nạp cấu hình từ hibernate.cfg.xml
			return new Configuration().configure().buildSessionFactory();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static SessionFactory getSessionFactory() {
		if (SESSION_FACTORY == null || SESSION_FACTORY.isClosed()) {
			SESSION_FACTORY = buildSessionFactory();
		}
		return SESSION_FACTORY;
	}
 
	public static void shutdown() {
		// Sửa lỗi logic: Chỉ đóng khi factory CHƯA đóng
		if (SESSION_FACTORY != null && !SESSION_FACTORY.isClosed()) {
			SESSION_FACTORY.close();
		}
		SESSION_FACTORY = null;
	}
}