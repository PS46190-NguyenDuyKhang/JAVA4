package utils;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class Mailer {
	public static void send(String to, String subject, String body) {
		final String username = "vn14122006@gmail.com";
		final String password = "qgmmzxytccafjcok";

		// Thông số kết nối GMail
		Properties props = new Properties();
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.starttls.enable", "true");
		props.setProperty("mail.smtp.host", "smtp.gmail.com");
		props.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
		props.setProperty("mail.smtp.port", "587");

		// Đăng nhập GMail
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// Tạo mail
			MimeMessage mail = new MimeMessage(session);
			
			// Thêm dòng này để định danh người gửi rõ ràng
			mail.setFrom(new InternetAddress(username));
			
			mail.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			mail.setSubject(subject, "utf-8");
			mail.setText(body, "utf-8", "html");
			mail.setReplyTo(mail.getFrom());

			// Gửi mail
			Transport.send(mail);
			System.out.println("Gửi mail thành công đến: " + to);
		} catch (Exception e) {
			System.out.println("Gửi mail thất bại: " + e.getMessage());
			e.printStackTrace();
		}
	}
}