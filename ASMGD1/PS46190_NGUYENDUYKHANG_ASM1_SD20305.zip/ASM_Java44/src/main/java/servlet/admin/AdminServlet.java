package servlet.admin;

import java.io.IOException;

import org.apache.commons.beanutils.BeanUtils;

import dao.FavoriteDAO;
import dao.ShareDAO;
import dao.UsersDAO;
import dao.VideoDAO;
import entity.Users;
import entity.Video;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({ "/admin", "/admin/videoManager/create", "/admin/videoManager/update", "/admin/videoManager/delete",
		"/admin/userManager", "/admin/userManager/create", "/admin/userManager/update", "/admin/userManager/delete",
		"/admin/reportFavorites", "/admin/reportFavoriteUser", "/admin/reportShareFriend" })
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// Khai báo DAO ở cấp class để tái sử dụng (hoặc khai báo trong method cũng được)
	private UsersDAO usersDAO = new UsersDAO();
	private VideoDAO videoDAO = new VideoDAO();
	private FavoriteDAO favoriteDAO = new FavoriteDAO();
	private ShareDAO shareDAO = new ShareDAO();

	public AdminServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uri = request.getRequestURI();
		
		// --- QUẢN LÝ USER ---
		if (uri.contains("/userManager")) {
			if (uri.contains("/userManager/update")) {
				String id = request.getParameter("id");
				Users user = usersDAO.findById(id);
				if (user != null) {
					request.setAttribute("user", user);
				} else {
					// Nếu không tìm thấy ID, quay về danh sách
					response.sendRedirect(request.getContextPath() + "/admin/userManager");
					return;
				}
			}
			request.setAttribute("listUsers", usersDAO.findAll());
			request.getRequestDispatcher("/views/admin/userManager.jsp").forward(request, response);
			return;
		
		// --- UPDATE VIDEO (FORM) ---
		} else if (uri.contains("/videoManager/update")) {
			String id = request.getParameter("id");
			Video video = videoDAO.findById(id);
			if (video != null) {
				request.setAttribute("video", video);
			} else {
				response.sendRedirect(request.getContextPath() + "/admin");
				return;
			}
		
		// --- BÁO CÁO YÊU THÍCH ---
		} else if (uri.contains("/reportFavorites")) {
			request.setAttribute("listReportFavorites", favoriteDAO.generateFavoriteReport());
			request.getRequestDispatcher("/views/admin/reportFavorites.jsp").forward(request, response);
			return;
			
		// --- BÁO CÁO NGƯỜI DÙNG LIKE VIDEO ---
		} else if (uri.contains("/reportFavoriteUser")) {
			request.setAttribute("listVideo", videoDAO.findAll());
			// Khi mới vào chưa chọn video thì listReport rỗng hoặc null
			request.getRequestDispatcher("/views/admin/reportFavoriteUser.jsp").forward(request, response);
			return;
			
		// --- BÁO CÁO CHIA SẺ ---
		} else if (uri.contains("/reportShareFriend")) {
			request.setAttribute("listVideo", videoDAO.findAll());
			request.getRequestDispatcher("/views/admin/reportShareFriend.jsp").forward(request, response);
			return;
		}
		
		// --- TRANG CHỦ ADMIN (LIST VIDEO) ---
		request.setAttribute("listVideo", videoDAO.findAll());
		request.getRequestDispatcher("/views/admin/home.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Bắt buộc để xử lý tiếng Việt trong form
		request.setCharacterEncoding("UTF-8");
		
		String uri = request.getRequestURI();
		
		// --- TẠO VIDEO MỚI ---
		if (uri.contains("/videoManager/create")) {
			try {
				Video video = new Video();
				BeanUtils.populate(video, request.getParameterMap());
				video.setViews(0); // Mặc định view = 0
				
				if (videoDAO.findById(video.getId()) != null) {
					request.setAttribute("video", video);
					request.setAttribute("messError", "Mã video này đã tồn tại!");
				} else {
					videoDAO.create(video);
					request.setAttribute("messSuccess", "Thêm video thành công");
				}
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("messError", "Lỗi: " + e.getMessage());
			}
			request.setAttribute("listVideo", videoDAO.findAll());
			request.getRequestDispatcher("/views/admin/home.jsp").forward(request, response);
			return;
			
		// --- CẬP NHẬT VIDEO ---
		} else if (uri.contains("/videoManager/update")) {
			try {
				String id = request.getParameter("id");
				Video video = videoDAO.findById(id);
				
				if (video != null) {
					// Cập nhật thủ công để an toàn hơn
					video.setTitle(request.getParameter("title"));
					video.setPoster(request.getParameter("poster"));
					video.setDescription(request.getParameter("description"));
					
					// Xử lý active (Checkbox: nếu không check thì trả về null -> false)
					String activeVal = request.getParameter("active");
					video.setActive(activeVal != null && activeVal.equals("true"));
					
					// Xử lý views (tránh lỗi parse Int)
					try {
						video.setViews(Integer.valueOf(request.getParameter("views")));
					} catch (NumberFormatException e) {
						video.setViews(0);
					}
					
					videoDAO.update(video);
					request.setAttribute("messSuccess", "Cập nhật video thành công");
				} else {
					request.setAttribute("messError", "Mã video không tồn tại");
				}
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("messError", "Lỗi cập nhật: " + e.getMessage());
			}
			request.setAttribute("listVideo", videoDAO.findAll());
			request.getRequestDispatcher("/views/admin/home.jsp").forward(request, response);
			return;
			
		// --- XÓA VIDEO ---
		} else if (uri.contains("/videoManager/delete")) {
			try {
				String id = request.getParameter("id");
				if (videoDAO.findById(id) != null) {
					if (videoDAO.deleteById(id)) {
						request.setAttribute("messSuccess", "Xóa video thành công");
					} else {
						request.setAttribute("messError", "Video này đã có người Like/Share, không thể xóa!");
					}
				} else {
					request.setAttribute("messError", "Mã video không tồn tại");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			request.setAttribute("listVideo", videoDAO.findAll());
			request.getRequestDispatcher("/views/admin/home.jsp").forward(request, response);
			return;
			
		// --- TẠO USER MỚI ---
		} else if (uri.contains("/userManager/create")) {
			try {
				Users user = new Users();
				BeanUtils.populate(user, request.getParameterMap());
				// Mặc định admin là false nếu không chọn (xử lý bởi BeanUtils hoặc thủ công)
				
				if (usersDAO.findById(user.getId()) != null) {
					request.setAttribute("user", user);
					request.setAttribute("messError", "Username này đã tồn tại!");
				} else {
					usersDAO.create(user);
					request.setAttribute("messSuccess", "Thêm user thành công");
				}
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("messError", "Lỗi: " + e.getMessage());
			}
			request.setAttribute("listUsers", usersDAO.findAll());
			request.getRequestDispatcher("/views/admin/userManager.jsp").forward(request, response);
			return;
			
		// --- CẬP NHẬT USER ---
		} else if (uri.contains("/userManager/update")) {
			try {
				String id = request.getParameter("id");
				Users user = usersDAO.findById(id);
				if (user != null) {
					user.setPassword(request.getParameter("password"));
					user.setFullname(request.getParameter("fullname"));
					user.setEmail(request.getParameter("email"));
					
					// Xử lý checkbox Admin
					String adminVal = request.getParameter("admin");
					user.setAdmin(adminVal != null && adminVal.equals("true"));
					
					usersDAO.update(user);
					request.setAttribute("messSuccess", "Cập nhật user thành công");
				} else {
					request.setAttribute("messError", "Username không tồn tại");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			request.setAttribute("listUsers", usersDAO.findAll());
			request.getRequestDispatcher("/views/admin/userManager.jsp").forward(request, response);
			return;
			
		// --- XÓA USER ---
		} else if (uri.contains("/userManager/delete")) {
			try {
				String id = request.getParameter("id");
				if (usersDAO.findById(id) != null) {
					if (usersDAO.deleteById(id)) {
						request.setAttribute("messSuccess", "Xóa user thành công");
					} else {
						request.setAttribute("messError", "User này đã có dữ liệu liên quan, không thể xóa!");
					}
				} else {
					request.setAttribute("messError", "Mã user không tồn tại");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			request.setAttribute("listUsers", usersDAO.findAll());
			request.getRequestDispatcher("/views/admin/userManager.jsp").forward(request, response);
			return;
			
		// --- XEM CHI TIẾT BÁO CÁO LIKE ---
		} else if (uri.contains("/reportFavoriteUser")) {
			String id = request.getParameter("id");
			request.setAttribute("listVideo", videoDAO.findAll());
			request.setAttribute("video", videoDAO.findById(id)); // Để hiển thị tiêu đề video đang chọn
			request.setAttribute("listReportFavoriteUser", favoriteDAO.findUsersByVideoId(id));
			request.getRequestDispatcher("/views/admin/reportFavoriteUser.jsp").forward(request, response);
			return;
			
		// --- XEM CHI TIẾT BÁO CÁO SHARE ---
		} else if (uri.contains("/reportShareFriend")) {
			String id = request.getParameter("id");
			request.setAttribute("listVideo", videoDAO.findAll());
			request.setAttribute("video", videoDAO.findById(id));
			// Sửa tên biến cho đúng nghĩa (Code cũ của bạn dùng listReportFavoriteUser ở đây gây nhầm lẫn)
			request.setAttribute("listReportShareFriend", shareDAO.findReportShareFriendsByVideoId(id));
			request.getRequestDispatcher("/views/admin/reportShareFriend.jsp").forward(request, response);
			return;
		}

	}
}