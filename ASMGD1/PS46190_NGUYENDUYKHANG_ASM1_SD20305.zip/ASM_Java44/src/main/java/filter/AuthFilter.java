package filter;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import entity.Users;

@WebFilter({ "/admin/*", "/changePassword", "/editProfile", "/likeVideo", "/videoFavorite" })
public class AuthFilter implements Filter {

	public AuthFilter() {
		super();
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession session = req.getSession();
		
		// Lấy user từ session
		Users user = (Users) session.getAttribute("currentUser");
		String uri = req.getRequestURI();

		// Logic kiểm tra quyền:
		// 1. user == null: Chưa đăng nhập -> Chặn.
		// 2. uri chứa "/admin/" VÀ user không phải admin -> Chặn.
		// Lưu ý: user.getAdmin() trả về Boolean, dùng Boolean.TRUE.equals để so sánh an toàn tránh NullPointerException
		boolean isNotAdmin = user != null && !Boolean.TRUE.equals(user.getAdmin());
		
		if (user == null || (uri.contains("/admin/") && isNotAdmin)) {
			// Chuyển hướng về trang đăng nhập
			res.sendRedirect(req.getContextPath() + "/signin");
		} else {
			// Cho phép đi tiếp
			chain.doFilter(request, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}