package entity;

import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name = "Share")
public class Share {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	// Khóa ngoại user_id
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user;

	// Khóa ngoại video_id
	@ManyToOne
	@JoinColumn(name = "video_id")
	private Video video;

	@Column(name = "emails")
	private String emails;

	@Temporal(TemporalType.DATE)
	@Column(name = "share_date")
	private Date shareDate = new Date();

	public Share() {
	}

	public Share(Users user, Video video, String emails, Date shareDate) {
		this.user = user;
		this.video = video;
		this.emails = emails;
		this.shareDate = shareDate;
	}

	// --- Getters and Setters ---
	public Integer getId() { return id; }
	public void setId(Integer id) { this.id = id; }

	public Users getUser() { return user; }
	public void setUser(Users user) { this.user = user; }

	public Video getVideo() { return video; }
	public void setVideo(Video video) { this.video = video; }

	public String getEmails() { return emails; }
	public void setEmails(String emails) { this.emails = emails; }

	public Date getShareDate() { return shareDate; }
	public void setShareDate(Date shareDate) { this.shareDate = shareDate; }
}