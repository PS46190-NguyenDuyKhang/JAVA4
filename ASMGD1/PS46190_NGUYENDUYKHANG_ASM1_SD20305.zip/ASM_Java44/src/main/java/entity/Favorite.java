package entity;

import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name = "Favorite", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"user_id", "video_id"}) // Đảm bảo 1 user chỉ like 1 video 1 lần
})
public class Favorite {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Tự tăng (Identity)
	@Column(name = "id")
	private Integer id;

	// Khóa ngoại user_id
	@ManyToOne
	@JoinColumn(name = "user_id")
	private Users user;

	// Khóa ngoại video_id
	@ManyToOne
	@JoinColumn(name = "video_id")
	private Video video;

	@Temporal(TemporalType.DATE)
	@Column(name = "share_date") // Trong SQL bạn đặt tên là share_date
	private Date likeDate = new Date(); // Map vào biến likeDate cho dễ hiểu nghĩa

	public Favorite() {
	}

	public Favorite(Users user, Video video, Date likeDate) {
		this.user = user;
		this.video = video;
		this.likeDate = likeDate;
	}

	// --- Getters and Setters ---
	public Integer getId() { return id; }
	public void setId(Integer id) { this.id = id; }

	public Users getUser() { return user; }
	public void setUser(Users user) { this.user = user; }

	public Video getVideo() { return video; }
	public void setVideo(Video video) { this.video = video; }

	public Date getLikeDate() { return likeDate; }
	public void setLikeDate(Date likeDate) { this.likeDate = likeDate; }
}