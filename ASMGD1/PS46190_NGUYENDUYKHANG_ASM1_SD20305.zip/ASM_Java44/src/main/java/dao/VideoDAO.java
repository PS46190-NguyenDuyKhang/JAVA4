package dao;

import java.util.ArrayList;
import java.util.List;

import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class VideoDAO implements DAOInterface<Video, String> {

	@Override
	public List<Video> findAll() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT v FROM Video v";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}

	public List<Video> findAllActive() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT v FROM Video v WHERE v.active = true";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}

	public List<Video> random10Video(String excludeId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			// Lưu ý: SQL Server dùng NEWID() để random, nhưng JPQL chuẩn dùng function('NEWID') hoặc rand()
			// Nếu chạy lỗi hàm RAND, hãy thử đổi thành "ORDER BY function('NEWID')"
			String jpql = "SELECT v FROM Video v WHERE v.id != :excludeId AND v.active = true ORDER BY function('NEWID')";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			query.setParameter("excludeId", excludeId);
			query.setMaxResults(10);
			return query.getResultList();
		} catch (Exception e) {
			// Fallback nếu NEWID không chạy (cho DB khác)
			String jpqlFallback = "SELECT v FROM Video v WHERE v.id != :excludeId AND v.active = true";
			TypedQuery<Video> query = manager.createQuery(jpqlFallback, Video.class);
			query.setParameter("excludeId", excludeId);
			query.setMaxResults(10);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}

	@Override
	public Video findById(String id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.find(Video.class, id);
		} finally {
			manager.close();
		}
	}

	@Override
	public void create(Video t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Video t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(String id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			Video entity = manager.find(Video.class, id);
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return false;
	}

	public List<Video> findVideosLikedByUser(String userId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT f.video FROM Favorite f WHERE f.user.id = :userId";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			query.setParameter("userId", userId);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}
}