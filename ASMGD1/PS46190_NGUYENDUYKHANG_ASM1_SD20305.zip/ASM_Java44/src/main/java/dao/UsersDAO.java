package dao;

import java.util.List;

import entity.Users;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class UsersDAO implements DAOInterface<Users, String> {
	
	@Override
	public List<Users> findAll() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			TypedQuery<Users> query = manager.createQuery("SELECT u FROM Users u", Users.class);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}

	@Override
	public Users findById(String id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.find(Users.class, id);
		} finally {
			manager.close();
		}
	}

	@Override
	public void create(Users t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Users t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(String id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			Users entity = manager.find(Users.class, id);
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return false;
	}

	public Users findByIdOrEmail(String idOrEmail) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT u FROM Users u WHERE u.id = :id OR u.email = :email";
			TypedQuery<Users> query = manager.createQuery(jpql, Users.class);
			query.setParameter("id", idOrEmail);
			query.setParameter("email", idOrEmail);
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		} finally {
			manager.close();
		}
	}
}