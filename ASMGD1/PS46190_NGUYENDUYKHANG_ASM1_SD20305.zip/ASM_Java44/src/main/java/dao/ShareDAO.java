package dao;

import java.util.List;

import dto.ReportShareFriend;
import entity.Share;
import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class ShareDAO implements DAOInterface<Share, Integer> {

	@Override
	public List<Share> findAll() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.createQuery("SELECT s FROM Share s", Share.class).getResultList();
		} finally {
			manager.close();
		}
	}

	@Override
	public Share findById(Integer id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.find(Share.class, id);
		} finally {
			manager.close();
		}
	}

	@Override
	public void create(Share t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Share t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(Integer id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			Share entity = manager.find(Share.class, id);
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return false;
	}

	// --- BÁO CÁO THỐNG KÊ ---

	public List<ReportShareFriend> findReportShareFriendsByVideoId(String videoId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			// Constructor: ReportShareFriend(String fullname, String email, String receiverEmail, Date sentDate)
			// Đã bỏ subquery lấy favoriteDate để khớp DTO
			String jpql = "SELECT new dto.ReportShareFriend(u.fullname, u.email, s.emails, s.shareDate) "
					+ "FROM Share s JOIN s.user u WHERE s.video.id = :videoId";
			TypedQuery<ReportShareFriend> query = manager.createQuery(jpql, ReportShareFriend.class);
			query.setParameter("videoId", videoId);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}
}