package dao;

import java.util.List;

import dto.ReportFavoriteUser;
import dto.ReportFavorites;
import entity.Favorite;
import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class FavoriteDAO implements DAOInterface<Favorite, Integer> {

	@Override
	public List<Favorite> findAll() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.createQuery("SELECT f FROM Favorite f", Favorite.class).getResultList();
		} finally {
			manager.close();
		}
	}

	@Override
	public Favorite findById(Integer id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			return manager.find(Favorite.class, id);
		} finally {
			manager.close();
		}
	}

	@Override
	public void create(Favorite t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Favorite t) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(Integer id) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			manager.getTransaction().begin();
			Favorite entity = manager.find(Favorite.class, id);
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return false;
	}

	// Các hàm nghiệp vụ riêng

	public Favorite findByUserIdAndVideoId(String userId, String videoId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT f FROM Favorite f WHERE f.user.id = :userId AND f.video.id = :videoId";
			TypedQuery<Favorite> query = manager.createQuery(jpql, Favorite.class);
			query.setParameter("userId", userId);
			query.setParameter("videoId", videoId);
			List<Favorite> list = query.getResultList();
			return list.isEmpty() ? null : list.get(0);
		} finally {
			manager.close();
		}
	}

	public List<Favorite> findFavoritesByUserId(String userId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			String jpql = "SELECT f FROM Favorite f WHERE f.user.id = :userId";
			TypedQuery<Favorite> query = manager.createQuery(jpql, Favorite.class);
			query.setParameter("userId", userId);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}
	
	// --- BÁO CÁO THỐNG KÊ (Đã sửa JPQL khớp với Entity và DTO) ---

	public List<ReportFavorites> generateFavoriteReport() {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			// Sửa shareDate -> likeDate (theo Entity)
			// Constructor: ReportFavorites(String title, Long favoriteCount, Date latestDate, Date oldestDate)
			String jpql = "SELECT new dto.ReportFavorites(f.video.title, COUNT(f), MAX(f.likeDate), MIN(f.likeDate)) "
					+ "FROM Favorite f GROUP BY f.video.title";
			TypedQuery<ReportFavorites> query = manager.createQuery(jpql, ReportFavorites.class);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}

	public List<ReportFavoriteUser> findUsersByVideoId(String videoId) {
		EntityManager manager = XJPA.getSessionFactory().createEntityManager();
		try {
			// Sửa shareDate -> likeDate
			// Constructor: ReportFavoriteUser(String id, String email, String fullname, Date favoriteDate)
			String jpql = "SELECT new dto.ReportFavoriteUser(u.id, u.email, u.fullname, f.likeDate) "
					+ "FROM Favorite f JOIN f.user u WHERE f.video.id = :videoId ORDER BY f.likeDate DESC";
			TypedQuery<ReportFavoriteUser> query = manager.createQuery(jpql, ReportFavoriteUser.class);
			query.setParameter("videoId", videoId);
			return query.getResultList();
		} finally {
			manager.close();
		}
	}
}