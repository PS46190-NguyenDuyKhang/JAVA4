package dto;

import java.util.Date;
import java.io.Serializable;

public class ReportFavorites implements Serializable {
	private String title;
	private Long favoriteCount; // Sửa thành Long để hứng count(*) từ DB
	private Date latestDate;
	private Date oldestDate;    // Đã sửa lỗi chính tả (cũ là oldestate)

	public ReportFavorites() {
	}

	public ReportFavorites(String title, Long favoriteCount, Date latestDate, Date oldestDate) {
		this.title = title;
		this.favoriteCount = favoriteCount;
		this.latestDate = latestDate;
		this.oldestDate = oldestDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getFavoriteCount() {
		return favoriteCount;
	}

	public void setFavoriteCount(Long favoriteCount) {
		this.favoriteCount = favoriteCount;
	}

	public Date getLatestDate() {
		return latestDate;
	}

	public void setLatestDate(Date latestDate) {
		this.latestDate = latestDate;
	}

	public Date getOldestDate() {
		return oldestDate;
	}

	public void setOldestDate(Date oldestDate) {
		this.oldestDate = oldestDate;
	}
}