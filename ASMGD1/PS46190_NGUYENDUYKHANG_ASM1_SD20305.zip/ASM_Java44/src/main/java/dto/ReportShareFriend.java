package dto;

import java.util.Date;
import java.io.Serializable;

public class ReportShareFriend implements Serializable {
	private String fullname;      // Tên người gửi
	private String email;         // Email người gửi
	private String receiverEmail; // Email người nhận
	private Date sentDate;        // Ngày gửi

	public ReportShareFriend() {
	}

	// Constructor này phải khớp thứ tự với câu SELECT new dto.ReportShareFriend(...)
	public ReportShareFriend(String fullname, String email, String receiverEmail, Date sentDate) {
		this.fullname = fullname;
		this.email = email;
		this.receiverEmail = receiverEmail;
		this.sentDate = sentDate;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReceiverEmail() {
		return receiverEmail;
	}

	public void setReceiverEmail(String receiverEmail) {
		this.receiverEmail = receiverEmail;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
}