package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class findPage {

	public static void main(String[] args)
	{
		findPage(1,5);
		
	}
	
	
private static void findPage(int page, int size) {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
	try {
		
		String jpql = "SELECT o FROM User o";
		// vi du co 100 phan tu
		// truyen page = 3, size = 15 >> co nghia la muon lay 15 phan tu bat dau tu phan tu thu 3
		
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setFirstResult(page * size);
		query.setMaxResults(size);
	
		List<User> list = query.getResultList();
	
		for(User user: list) {
			System.out.println(">>Email: " + user.getEmail());
			System.out.println(">>Is Admin: " + user.getAdmin());
		}

		System.out.println("Truy van thanh cong!");
	} catch (Exception e) {
		System.out.println("Truy van that bai!");
	}
	em.close();
	emf.close();
}

}
