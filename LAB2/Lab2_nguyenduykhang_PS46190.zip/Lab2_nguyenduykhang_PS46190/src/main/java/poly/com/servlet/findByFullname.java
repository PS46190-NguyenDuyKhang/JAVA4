package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class findByFullname {

	public static void main(String[] args)
	{
		findByFullname("HELLO");
		
	}
	
private static void findByFullname(String fullname) {
    // Nạp EntityManagerFactory
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
    EntityManager em = emf.createEntityManager();
    try {
        String jpql = "SELECT o FROM User o WHERE o.Fullname LIKE :fullname";
        // Tạo đối tượng truy vấn
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setParameter("fullname", "%" + fullname + "%");
        List<User> list = query.getResultList();

        // Hiển thị kết quả
        for (User user : list) {
            System.out.println(">>Email: " + user.getEmail());
            System.out.println(">>Fullname: " + user.getFullname());
            System.out.println(">>Is Admin: " + user.getAdmin());
        }
        System.out.println("Truy vấn thành công!");
    } catch (Exception e) {
        System.out.println("Truy vấn thất bại! Lỗi: " + e.getMessage());
    } finally {
        em.close();
        emf.close();
    }
}	
	

}
