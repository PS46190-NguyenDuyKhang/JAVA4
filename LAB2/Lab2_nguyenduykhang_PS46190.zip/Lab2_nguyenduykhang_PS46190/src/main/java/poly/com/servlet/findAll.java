package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class findAll {

	public static void main(String[] args)
	{
		findAll();
		
	}
	
	
	private static void findAll() {
	    EntityManagerFactory emf = null;
	    EntityManager em = null;

	    try {
	        // Nạp persistence unit
	        emf = Persistence.createEntityManagerFactory("PolyOE");
	        em = emf.createEntityManager();
	        String jpql = "SELECT u FROM User u";
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        List<User> list = query.getResultList();

	        for (User user : list) {
	            System.out.println(">> Email: " + user.getEmail());
	            System.out.println(">> Quyen: " + user.getAdmin());
	            System.out.println(">> ID: " + user.getId());
	            System.out.println(">> Password: " + user.getPassword());
	            System.out.println(">> Ten day du: " + user.getFullname());
	            System.out.println("----------------------------");
	        }

	        System.out.println("Truy van thanh cong!");

	    }
	    catch (Exception e) {
	        System.out.println("Truy van that bai!");
	        e.printStackTrace();
	    } finally {
	        if (em != null && em.isOpen()) {
	            em.close();
	        }
	        if (emf != null && emf.isOpen()) {
	            emf.close();
	        }
	    }
	}

}
