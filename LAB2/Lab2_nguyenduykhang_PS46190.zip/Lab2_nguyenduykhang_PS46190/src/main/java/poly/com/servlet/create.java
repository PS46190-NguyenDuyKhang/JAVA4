package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class create {

	public static void main(String[] args)
	{
		 
		create();
		
	}


	private static void create() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try
		{
			em.getTransaction().begin(); 
			User entity = new User();
			
			entity.setId("nv1218");
			entity.setEmail("vn14122006@gmail.com");
			entity.setPassword("142857");
			entity.setFullname("HELLO SD305");
			entity.setAdmin(true);
			em.persist(entity);

			em.getTransaction().commit();
			
			System.out.println("thêm thành công !");
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("fail");
		}
		em.close();
		emf.close();
	}
	

}
