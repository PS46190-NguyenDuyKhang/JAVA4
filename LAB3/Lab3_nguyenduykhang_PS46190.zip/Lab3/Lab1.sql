﻿USE master
GO
-- Xóa DB cũ đi tạo lại cho sạch (nếu muốn)
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'PolyOE')
    DROP DATABASE PolyOE
GO
CREATE DATABASE PolyOE
GO
USE PolyOE
GO

-- 1. Tạo bảng USERS
CREATE TABLE Users(
	Id NVARCHAR(50) NOT NULL PRIMARY KEY,
	Password NVARCHAR(50) NOT NULL,
	Fullname NVARCHAR(100) NOT NULL,
	Email NVARCHAR(100) NOT NULL UNIQUE,
	Admin BIT NOT NULL
)
GO

-- 2. Tạo bảng VIDEO (Bắt buộc phải có mới chạy được trang Favorites)
CREATE TABLE Video(
	Id NVARCHAR(50) NOT NULL PRIMARY KEY,
	Title NVARCHAR(200) NOT NULL,
	Poster NVARCHAR(200),
	Views INT NOT NULL DEFAULT 0,
	Description NVARCHAR(MAX),
	Active BIT NOT NULL DEFAULT 1
)
GO

-- 3. Tạo bảng FAVORITE (Bảng trung gian lưu lượt thích)
CREATE TABLE Favorite(
	Id BIGINT IDENTITY(1,1) PRIMARY KEY,
	UserId NVARCHAR(50) NOT NULL,
	VideoId NVARCHAR(50) NOT NULL,
	LikeDate DATE NOT NULL DEFAULT GETDATE(),
	FOREIGN KEY (UserId) REFERENCES Users(Id),
	FOREIGN KEY (VideoId) REFERENCES Video(Id),
    UNIQUE(UserId, VideoId) -- Một người không thích 1 video 2 lần
)
GO

-- ================= INSERT DỮ LIỆU =================

-- Thêm Users (Dữ liệu của bạn + thêm Admin chuẩn)
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('admin01', '123', N'Nguyễn Văn Admin', 'admin01@example.com', 1),
('user01', '123', N'Trần Thị Bê', 'tranthib@example.com', 0),
('user02', '123', N'Lê Hoàng Cê', 'lehoangc@example.com', 0),
('teonv', '123', N'Nguyễn Văn Tèo', 'teo@gmail.com', 0);
GO

-- Thêm Videos (QUAN TRỌNG: Phải có cái này web mới hiện danh sách)
INSERT INTO Video (Id, Title, Poster, Views, Description, Active) VALUES
('V01', N'Lập trình Java Web', NULL, 1500, N'Học JSP Servlet cơ bản', 1),
('V02', N'Hướng dẫn Hibernate', NULL, 2300, N'Kết nối CSDL Java', 1),
('V03', N'Review Phim Mới', NULL, 5000, N'Phim hành động hay nhất', 1);
GO

-- Thêm lượt thích (Favorite) để test trang "All Favorites"
INSERT INTO Favorite (UserId, VideoId, LikeDate) VALUES
('user01', 'V01', '2023-11-20'), -- User01 thích Java Web
('user01', 'V02', '2023-11-21'), -- User01 thích Hibernate
('teonv', 'V03', '2023-11-22'),  -- Tèo thích Phim
('admin01', 'V01', GETDATE());   -- Admin cũng thích Java Web
GO