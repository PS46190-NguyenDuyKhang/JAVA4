package entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Users")
public class User {

    @Id
    private String id;

    private String fullName;
    private String password;

    @Column(name = "Role")
    private boolean admin;

    // Getter - Setter

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // 👉 BẮT BUỘC có method này
    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
}
