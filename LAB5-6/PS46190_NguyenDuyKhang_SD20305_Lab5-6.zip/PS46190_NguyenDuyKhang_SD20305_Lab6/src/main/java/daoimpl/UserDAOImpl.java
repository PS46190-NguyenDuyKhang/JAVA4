package daoimpl;

import dao.UserDAO;
import entity.User;
import jakarta.persistence.*;

public class UserDAOImpl implements UserDAO {

    EntityManager em = Persistence
            .createEntityManagerFactory("Lab6jav4")
            .createEntityManager();

    @Override
    public User findById(String id) {
        return em.find(User.class, id);
    }
}
